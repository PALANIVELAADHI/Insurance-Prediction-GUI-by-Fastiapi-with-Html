import pandas as pd
import numpy as np
from sklearn.datasets import make_classification

# Generate synthetic classification data
X, y = make_classification(
    n_samples=500, 
    n_features=20, 
    n_informative=10, 
    n_clusters_per_class=2, 
    random_state=42
)

# Give names to each feature related to life insurance
columns = [
    "Age", 
    "Income", 
    "Policy_Term", 
    "Premium_Amount", 
    "Coverage_Amount", 
    "Health_Score", 
    "Policy_Type", 
    "Marital_Status", 
    "Children_Count", 
    "Employment_Status", 
    "Education_Level", 
    "Loan_Amount", 
    "Credit_Score", 
    "Location_Type", 
    "Gender", 
    "Policy_Payment_Frequency", 
    "Past_Claim_History", 
    "Smoking_Status", 
    "Health_Conditions", 
    "Risk_Level"
]

# Convert to DataFrame
data = pd.DataFrame(X, columns=columns)

# Add target column
data['Target'] = y

# Save data to CSV
data.to_csv("life_insurance_data.csv", index=False)
