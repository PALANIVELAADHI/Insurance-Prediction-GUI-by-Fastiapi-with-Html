from fastapi import FastAPI, File, UploadFile
from fastapi.responses import HTMLResponse
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score
import pandas as pd
import matplotlib.pyplot as plt
import io
import base64

app = FastAPI()

# Function to generate base64 encoded images
def generate_image_from_plot(fig: plt.Figure) -> str:
    """Convert a matplotlib figure to a base64 encoded PNG image."""
    img_bytes = io.BytesIO()
    fig.savefig(img_bytes, format='png')
    img_bytes.seek(0)
    img_base64 = base64.b64encode(img_bytes.getvalue()).decode('utf-8')
    return img_base64

# Function to handle file upload and model training
@app.post("/uploadfile/")
async def create_upload_file(file: UploadFile = File(...)):
    # Read the CSV data from the uploaded file
    contents = await file.read()
    df = pd.read_csv(io.StringIO(contents.decode("utf-8")))

    # Ensure the target column is present
    if 'Target' not in df.columns:
        return HTMLResponse(content="<html><body><h1>Error: The uploaded file must contain a 'Target' column</h1></body></html>")
    
    # Prepare features and target variable
    X = df.drop(columns='Target')
    y = df['Target']
    
    # Train-test split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Train models
    rf_model = RandomForestClassifier(random_state=42).fit(X_train, y_train)
    svm_model = SVC(random_state=42).fit(X_train, y_train)

    # Model predictions and accuracy
    rf_pred = rf_model.predict(X_test)
    svm_pred = svm_model.predict(X_test)
    rf_accuracy = accuracy_score(y_test, rf_pred)
    svm_accuracy = accuracy_score(y_test, svm_pred)

    # Model comparison plot
    fig1, ax1 = plt.subplots(figsize=(6, 4))
    models = ['Random Forest', 'SVM']
    accuracies = [rf_accuracy, svm_accuracy]
    ax1.bar(models, accuracies, color=['blue', 'red'])
    ax1.set_title("Model Accuracy Comparison")
    ax1.set_ylabel("Accuracy")
    model_comparison_img = generate_image_from_plot(fig1)

    # Additional insights and plots
    plot_images = []
    additional_insights = "<h2>Additional Insights</h2>"

    # 1. Age Distribution Plot
    if 'Age' in df.columns:
        fig2, ax2 = plt.subplots(figsize=(6, 4))
        df['Age'].dropna().hist(color='skyblue', edgecolor='black', bins=20)
        ax2.set_title("Age Distribution")
        ax2.set_xlabel("Age")
        ax2.set_ylabel("Frequency")
        age_dist_img = generate_image_from_plot(fig2)
        plot_images.append(f"<h4>Age Distribution</h4><img src='data:image/png;base64,{age_dist_img}' />")

    # 2. Health Condition Distribution Plot
    if 'HealthCondition' in df.columns:
        df['HealthCondition'] = df['HealthCondition'].fillna('Unknown')
        fig3, ax3 = plt.subplots(figsize=(6, 4))
        health_condition_counts = df['HealthCondition'].value_counts()
        health_condition_counts.plot(kind='bar', color='lightcoral', edgecolor='black', ax=ax3)
        ax3.set_title("Health Condition Distribution")
        ax3.set_xlabel("Health Condition")
        ax3.set_ylabel("Count")
        health_condition_img = generate_image_from_plot(fig3)
        plot_images.append(f"<h4>Health Condition Distribution</h4><img src='data:image/png;base64,{health_condition_img}' />")

    # 3. Risk Level vs Health Score Plot
    if 'RiskLevel' in df.columns and 'HealthScore' in df.columns:
        df['RiskLevel'] = df['RiskLevel'].fillna('Unknown')
        df['HealthScore'] = df['HealthScore'].fillna(df['HealthScore'].mean())  # Fill missing HealthScore with mean
        fig4, ax4 = plt.subplots(figsize=(6, 4))
        risk_vs_health = df.groupby('RiskLevel')['HealthScore'].mean()
        risk_vs_health.plot(kind='bar', color='lightgreen', edgecolor='black', ax=ax4)
        ax4.set_title("Risk Level vs Health Score")
        ax4.set_xlabel("Risk Level")
        ax4.set_ylabel("Average Health Score")
        risk_level_img = generate_image_from_plot(fig4)
        plot_images.append(f"<h4>Risk Level vs Health Score</h4><img src='data:image/png;base64,{risk_level_img}' />")

    # Return the model results and the plots
    return HTMLResponse(content=f"""
    <html>
        <head><title>Model Prediction Results</title></head>
        <body>
            <h1>Model Performance Results</h1>
            <p><strong>Random Forest Accuracy:</strong> {rf_accuracy:.2f}</p>
            <p><strong>SVM Accuracy:</strong> {svm_accuracy:.2f}</p>
            <h2>Model Accuracy Comparison</h2>
            <img src="data:image/png;base64,{model_comparison_img}" />
            {additional_insights}
            {"".join(plot_images)}
        </body>
    </html>
    """)

# Home route
@app.get("/")
async def home():
    return HTMLResponse(content=""" 
    <html>
        <head><title>Life Insurance Prediction</title></head>
        <body>
            <h1>Upload Life Insurance Data for Prediction</h1>
            <form action="/uploadfile/" method="post" enctype="multipart/form-data">
                <input type="file" name="file">
                <input type="submit">
            </form>
        </body>
    </html>
    """)
